function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 225, 225, 225, 1);
}

function draw() {
  background(115);
  
  for (let d = 300; d > 0; d-=20){
    fill(225, 225, 225, 1);
    stroke(10, 85, 60, 1);
    strokeWeight(3);
    circle(200, 200, d);}
  
  if(mouseIsPressed === true){
    fill(150, 30, 78, 1);
    noStroke();
   circle (200, 200, 300);}

  if (keyIsPressed === true){
    if (key === 'r'){
      fill('red')}
    }
   circle(200, 200, 100);
  }