function setup() {
  createCanvas(128,128);
  colorMode(RGB, 225, 225, 225, 1);
}

function draw() {
  background(25);

  //green planet
  fill(80, 150, 45, 1);
  stroke(80, 170, 20, 1);
  strokeWeight(3);
  ellipse(25, 27, 30, 30);

  //shooting star
  fill(225, 225, 0, 1);
  stroke(200, 120, 0, 1);
  strokeWeight(2);
  beginShape();
  vertex(47, 65);
  vertex(50, 60);
  vertex(53,65);
  
  vertex(53, 65);
  vertex(58, 65);
  vertex(53, 70);

  vertex(53, 70);
  vertex(55, 75);
  vertex(50, 72);

  vertex(50, 72);
  vertex(46, 75);
  vertex(47,72);

  vertex(47, 72);
  vertex(42, 65);
  vertex(47, 65);
  
  endShape();

  //shooting star trail
  fill(225, 182, 193);
  stroke(225, 105, 180);
  triangle(15, 75, 43, 71, 20, 84);

  //planet with ring
  fill(150, 0, 220, 1);
  stroke(160, 0, 180, 1);
  arc(93, 100, 30, 30, -0.1, PI + QUARTER_PI);
  //ring
  fill(210, 40, 50, 1);
  noStroke();
  ellipse(93, 100, 50, 10);
  //top of planet
  fill(150, 0, 220, 1);
  stroke(160, 0, 180, 1);
  arc(93, 97, 30, 30, PI, TWO_PI);

  //blue planet
  fill(0, 100, 140, 1);
  noStroke();
  ellipse(50, 110, 20, 20);

  //dark red planet
  fill(110, 0, 30, 1);
  ellipse(115, 40, 50, 50);

  //teal planet
  fill(0, 110, 90, 1);
  ellipse(70, 35, 20, 20);

  
}