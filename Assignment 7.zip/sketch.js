function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 225, 225, 225, 1)
  print('weather is sunny and clear today')
}

function draw() {
  background(0, 120, 225, 1);

  //sun center
  fill(215, 200, 0, 1);
  noStroke();
  ellipse(330, 70, 100, 100);

  push();
  angleMode(DEGREES);
  let angle = 360 / 7;
  translate(330, 70);
  noStroke();
  // sun rays
  for (let i = 0; i < 7; i += 1) {
  triangle(40, 20, 30, 40, 70, 50);
    rotate(angle);
  }

  pop();

  //cloud duplication
  let xCoordinates = [20, 40, 60];

for (let i = 0; i < xCoordinates.length; i += 1) {

  xCoordinates[i] += random(-1, 1);
  
  let x = frameCount * 0.2;
  translate(x, 170);
  
  //clouds
  push();

  noStroke();
  fill(225, 225, 225, 1);
  circle(0, 0, 60);
  circle(30, 0, 80);
  circle(60, 10, 60);

  scale(0.7);
  circle(200, -90, 80);
  circle(160, -85, 60);
  circle(240, -85, 60);

  pop();

}
}